import { useState, useRef, useEffect } from "react";

const C = {
  bg: "#EEF6F3", white: "#FFFFFF",
  blue2: "#2E7DA6", blue3: "#B8DDF0",
  green2: "#2D8C65", green3: "#C0E8D5",
  navy: "#1B4F72", muted: "#7aafc4",
};
const FF = "'Noto Kufi Arabic', sans-serif";

// ─── ElevenLabs Voice (Heba) ─────────────────────────────────────────────────
const XI_KEY     = "sk_9242767bb4c5f0f54187b8d348028426f56130eee1033916";
const XI_VOICE   = "JHdGl5PsEzushIzzVSd1";
let currentAudio = null;

async function speakArabic(text) {
  try {
    if (currentAudio) { currentAudio.pause(); currentAudio = null; }
    const res = await fetch(
      `https://api.elevenlabs.io/v1/text-to-speech/${XI_VOICE}`,
      {
        method: "POST",
        headers: { "xi-api-key": XI_KEY, "Content-Type": "application/json" },
        body: JSON.stringify({
          text,
          model_id: "eleven_multilingual_v2",
          voice_settings: { stability: 0.5, similarity_boost: 0.75 },
        }),
      }
    );
    if (!res.ok) throw new Error("XI error");
    const blob = await res.blob();
    const url  = URL.createObjectURL(blob);
    currentAudio = new Audio(url);
    currentAudio.onended = () => URL.revokeObjectURL(url);
    await currentAudio.play();
  } catch {
    // fallback TTS
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "ar-SA"; u.rate = 0.82;
    const vs = window.speechSynthesis.getVoices();
    const v  = vs.find(x => x.lang === "ar-SA") || vs.find(x => x.lang.startsWith("ar"));
    if (v) u.voice = v;
    window.speechSynthesis.speak(u);
  }
}

// ─── Data ────────────────────────────────────────────────────────────────────
const MORNING_STEPS = [
  { ar: "أصحى من النوم", icon: "☀️", bg: "#FFF8E1" },
  { ar: "أغسل وشي",      icon: "🚿", bg: "#E3F4FF" },
  { ar: "ألبس هدومي",    icon: "👕", bg: "#E8FFE8" },
  { ar: "آكل فطاري",     icon: "🍳", bg: "#FFF3E0" },
  { ar: "أفرش سناني",    icon: "🦷", bg: "#E0F7FA" },
  { ar: "أشيل شنطتي",   icon: "🎒", bg: "#EDE7FF" },
];

const NIGHT_STEPS = [
  { ar: "آكل عشايا",     icon: "🍽", bg: "#FFF3E0" },
  { ar: "أستحمى",        icon: "🛁", bg: "#E3F4FF" },
  { ar: "أفرش سناني",    icon: "🦷", bg: "#E0F7FA" },
  { ar: "ألبس البيجامة", icon: "🌙", bg: "#EDE7FF" },
  { ar: "أقرأ قصة",      icon: "📖", bg: "#E8FFE8" },
  { ar: "أنام",          icon: "😴", bg: "#E8EEF8" },
];

const CATS = {
  food:     { label: "الطعام",  emoji: "🍎", color: "#4BAF82", items: [{ar:"تفاحة",e:"🍎"},{ar:"موز",e:"🍌"},{ar:"عيش",e:"🍞"},{ar:"لبن",e:"🥛"},{ar:"مية",e:"💧"},{ar:"تمر",e:"🟤"},{ar:"رز",e:"🍚"},{ar:"بيضة",e:"🥚"}] },
  places:   { label: "الأماكن", emoji: "🏠", color: "#4A9FBF", items: [{ar:"البيت",e:"🏠"},{ar:"المدرسة",e:"🏫"},{ar:"الجنينة",e:"🌳"},{ar:"الجامع",e:"🕌"},{ar:"الدكتور",e:"🏥"},{ar:"العربية",e:"🚗"}] },
  family:   { label: "العائلة", emoji: "👪", color: "#7B8FBF", items: [{ar:"ماما",e:"👩"},{ar:"بابا",e:"👨"},{ar:"أخويا",e:"👦"},{ar:"أختي",e:"👧"},{ar:"تيتا",e:"👵"},{ar:"جدو",e:"👴"}] },
  emotions: { label: "المشاعر", emoji: "😊", color: "#5BA88E", items: [{ar:"فرحان",e:"😊"},{ar:"زعلان",e:"😢"},{ar:"خايف",e:"😨"},{ar:"متضايق",e:"😠"},{ar:"تعبان",e:"😴"},{ar:"محتاج مساعدة",e:"🙋"}] },
  others:   { label: "أخرى",   emoji: "✨", color: "#6B9FB5", items: [{ar:"ألعب",e:"🎮"},{ar:"كتاب",e:"📚"},{ar:"موسيقى",e:"🎵"},{ar:"تلفزيون",e:"📺"},{ar:"نوم",e:"🌙"},{ar:"حمام",e:"🚿"}] },
};

function toMins(t) { const [h, m] = (t || "07:00").split(":").map(Number); return h * 60 + m; }
function nowMins() { const d = new Date(); return d.getHours() * 60 + d.getMinutes(); }
function whichRoutine(p) {
  const now = nowMins(), wake = toMins(p.wake), bed = toMins(p.bed);
  if (now >= wake && now < wake + 120) return "morning";
  if (now >= bed - 60 && now < bed + 90) return "night";
  return null;
}

// ─── ONBOARDING ──────────────────────────────────────────────────────────────
function Onboarding({ onDone }) {
  const [name, setName]     = useState("");
  const [age, setAge]       = useState("");
  const [gender, setGender] = useState("ذكر");
  const [wake, setWake]     = useState("07:00");
  const [bed, setBed]       = useState("21:00");
  const [friend, setFriend] = useState("");
  const [photo, setPhoto]   = useState(null);
  const fileRef = useRef();
  const valid = name.trim() && age && friend.trim();

  const inp = { width:"100%", padding:"13px 14px", borderRadius:14, border:`2px solid ${C.blue3}`, fontSize:16, fontFamily:FF, color:C.navy, background:"#F4FAFE", outline:"none", textAlign:"right", boxSizing:"border-box" };

  return (
    <div style={{ minHeight:"100vh", background:C.bg, display:"flex", alignItems:"center", justifyContent:"center", padding:20, direction:"rtl" }}>
      <div style={{ width:"100%", maxWidth:440 }}>
        <div style={{ textAlign:"center", marginBottom:20 }}>
          <div style={{ width:72, height:72, borderRadius:"50%", background:`linear-gradient(135deg,${C.blue2},${C.green2})`, display:"flex", alignItems:"center", justifyContent:"center", margin:"0 auto 10px" }}>
            <span style={{ fontSize:36 }}>⭐</span>
          </div>
          <h1 style={{ fontFamily:FF, color:C.navy, fontSize:23, margin:0 }}>مرحباً بك</h1>
          <p style={{ color:C.muted, fontSize:13, marginTop:4 }}>سجّل بيانات طفلك للبدء</p>
        </div>

        <div style={{ background:C.white, borderRadius:24, padding:"20px 18px", boxShadow:"0 4px 18px rgba(0,0,0,.08)" }}>
          <div style={{ marginBottom:13 }}>
            <label style={{ display:"block", color:C.navy, fontWeight:700, marginBottom:5, fontSize:14 }}>اسم الطفل</label>
            <input style={inp} value={name} onChange={e=>setName(e.target.value)} placeholder="مثال: محمد"/>
          </div>

          <div style={{ marginBottom:13 }}>
            <label style={{ display:"block", color:C.navy, fontWeight:700, marginBottom:7, fontSize:14 }}>العمر (سنوات)</label>
            <div style={{ display:"flex", gap:7, flexWrap:"wrap" }}>
              {[3,4,5,6,7,8,9].map(a => (
                <button key={a} onClick={()=>setAge(String(a))}
                  style={{ width:44, height:44, borderRadius:11, border:`2px solid ${age===String(a)?C.blue2:C.blue3}`, background:age===String(a)?C.blue2:"#F4FAFE", color:age===String(a)?C.white:C.navy, fontFamily:FF, fontSize:17, fontWeight:700, cursor:"pointer" }}>
                  {a}
                </button>
              ))}
            </div>
          </div>

          <div style={{ marginBottom:13 }}>
            <label style={{ display:"block", color:C.navy, fontWeight:700, marginBottom:5, fontSize:14 }}>الجنس</label>
            <div style={{ display:"flex", gap:10 }}>
              {["ذكر","أنثى"].map(g => (
                <button key={g} onClick={()=>setGender(g)}
                  style={{ flex:1, padding:"10px 0", borderRadius:11, border:`2px solid ${gender===g?C.blue2:C.blue3}`, background:gender===g?C.blue2:"#F4FAFE", color:gender===g?C.white:C.navy, fontFamily:FF, fontSize:14, cursor:"pointer", fontWeight:700 }}>
                  {g}
                </button>
              ))}
            </div>
          </div>

          <div style={{ marginBottom:13 }}>
            <label style={{ display:"block", color:C.navy, fontWeight:700, marginBottom:5, fontSize:14 }}>اسم الرفيق</label>
            <input style={inp} value={friend} onChange={e=>setFriend(e.target.value)} placeholder="مثال: نجمة، زيد..."/>
          </div>

          <div style={{ display:"flex", gap:10, marginBottom:13 }}>
            <div style={{ flex:1 }}>
              <label style={{ display:"block", color:C.navy, fontWeight:700, marginBottom:5, fontSize:14 }}>وقت الاستيقاظ</label>
              <input style={inp} type="time" value={wake} onChange={e=>setWake(e.target.value)}/>
            </div>
            <div style={{ flex:1 }}>
              <label style={{ display:"block", color:C.navy, fontWeight:700, marginBottom:5, fontSize:14 }}>وقت النوم</label>
              <input style={inp} type="time" value={bed} onChange={e=>setBed(e.target.value)}/>
            </div>
          </div>

          <div style={{ marginBottom:16 }}>
            <label style={{ display:"block", color:C.navy, fontWeight:700, marginBottom:5, fontSize:14 }}>صورة الطفل</label>
            <div onClick={()=>fileRef.current.click()} style={{ border:`2px dashed ${C.blue3}`, borderRadius:13, padding:14, textAlign:"center", cursor:"pointer", background:"#F4FAFE" }}>
              {photo
                ? <img src={photo} alt="" style={{ width:76, height:76, borderRadius:"50%", objectFit:"cover" }}/>
                : <><div style={{ fontSize:34 }}>📷</div><p style={{ color:C.muted, margin:"5px 0 0", fontSize:13 }}>اضغط لرفع الصورة</p></>}
            </div>
            <input ref={fileRef} type="file" accept="image/*" style={{ display:"none" }}
              onChange={e=>{ const f=e.target.files[0]; if(f){const r=new FileReader();r.onload=ev=>setPhoto(ev.target.result);r.readAsDataURL(f);} }}/>
          </div>

          <button onClick={()=>valid&&onDone({name,age,gender,wake,bed,friend,photo})}
            style={{ width:"100%", padding:"14px 0", borderRadius:15, border:"none", background:valid?`linear-gradient(90deg,${C.green2},${C.blue2})`:"#ccc", color:C.white, fontFamily:FF, fontSize:17, fontWeight:700, cursor:valid?"pointer":"not-allowed" }}>
            ابدأ الرحلة 🌟
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── ROUTINE ─────────────────────────────────────────────────────────────────
function RoutineScreen({ profile, type, onComplete, onCalm }) {
  const steps  = type === "morning" ? MORNING_STEPS : NIGHT_STEPS;
  const isMorn = type === "morning";
  const [idx, setIdx]     = useState(0);
  const [tapped, setTapped] = useState(false);
  const [done, setDone]   = useState(false);

  const bgGrad = isMorn ? "linear-gradient(160deg,#D4F0FF,#E8F8EE)" : "linear-gradient(160deg,#1a2f45,#1e3d54)";
  const txtCol = isMorn ? C.navy : "#D4EEFF";
  const subCol = isMorn ? C.muted : "#7aaccc";

  useEffect(() => {
    setTapped(false);
    if (!done && steps[idx]) speakArabic(steps[idx].ar);
  }, [idx, done]);

  function tap() {
    if (tapped) return;
    setTapped(true);
    speakArabic("شاطر");
    setTimeout(() => { if (idx + 1 < steps.length) setIdx(i => i + 1); else setDone(true); }, 900);
  }

  if (done) return (
    <div style={{ minHeight:"100vh", background:bgGrad, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", direction:"rtl", padding:24 }}>
      <div style={{ fontSize:96, marginBottom:16 }}>🌟</div>
      <h2 style={{ fontFamily:FF, fontSize:30, color:txtCol, margin:"0 0 8px", textAlign:"center" }}>شاطر يا {profile.name}!</h2>
      <p style={{ fontFamily:FF, fontSize:17, color:subCol, textAlign:"center", marginBottom:34 }}>يلا نتكلم!</p>
      <button onClick={onComplete} style={{ padding:"17px 50px", borderRadius:20, border:"none", background:`linear-gradient(90deg,${C.green2},${C.blue2})`, color:C.white, fontFamily:FF, fontSize:19, fontWeight:700, cursor:"pointer" }}>
        لوحة التواصل 💬
      </button>
    </div>
  );

  const step = steps[idx];
  return (
    <div style={{ minHeight:"100vh", background:bgGrad, direction:"rtl", display:"flex", flexDirection:"column" }}>
      <div style={{ padding:"14px 16px", display:"flex", alignItems:"center", justifyContent:"space-between" }}>
        {isMorn ? (
          <button onClick={onCalm} style={{ background:"rgba(255,255,255,.22)", border:"none", borderRadius:12, padding:"7px 13px", color:txtCol, fontFamily:FF, fontSize:13, fontWeight:700, cursor:"pointer", display:"flex", alignItems:"center", gap:6 }}>
            <svg viewBox="0 0 32 32" width="18" height="18" fill="none"><circle cx="16" cy="16" r="13" fill="rgba(255,255,255,0.3)"/><ellipse cx="11" cy="13" rx="2" ry="2.5" fill={txtCol}/><ellipse cx="21" cy="13" rx="2" ry="2.5" fill={txtCol}/><path d="M10 20 Q16 26 22 20" stroke={txtCol} strokeWidth="2" fill="none" strokeLinecap="round"/></svg>
            هدوء
          </button>
        ) : (
          <button onClick={onComplete} style={{ background:"rgba(255,255,255,.18)", border:"none", borderRadius:12, width:42, height:42, display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer" }}>
            <svg viewBox="0 0 24 24" fill="none" width="22" height="22"><path d="M9 5l7 7-7 7" stroke="#D4EEFF" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
        )}
        <span style={{ fontFamily:FF, fontSize:17, fontWeight:700, color:txtCol }}>{isMorn ? "☀️ روتين الصباح" : "🌙 روتين المساء"}</span>
        <div style={{ display:"flex", alignItems:"center", gap:8 }}>
          <span style={{ fontFamily:FF, fontSize:14, color:subCol, fontWeight:700 }}>{idx+1}/{steps.length}</span>
          {!isMorn && (
            <button onClick={onCalm} style={{ background:"rgba(255,255,255,.18)", border:"none", borderRadius:10, width:36, height:36, display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer" }}>
              <svg viewBox="0 0 32 32" width="20" height="20" fill="none"><circle cx="16" cy="16" r="13" fill="rgba(255,255,255,0.25)"/><ellipse cx="11" cy="13" rx="2" ry="2.5" fill="#D4EEFF"/><ellipse cx="21" cy="13" rx="2" ry="2.5" fill="#D4EEFF"/><path d="M10 20 Q16 26 22 20" stroke="#D4EEFF" strokeWidth="2" fill="none" strokeLinecap="round"/></svg>
            </button>
          )}
        </div>
      </div>

      <div style={{ margin:"0 16px 16px", height:9, borderRadius:9, background:"rgba(255,255,255,.22)", overflow:"hidden" }}>
        <div style={{ height:"100%", width:`${(idx/steps.length)*100}%`, background:`linear-gradient(90deg,${C.green2},${C.blue2})`, borderRadius:9, transition:"width .4s" }}/>
      </div>

      <div style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:"0 18px 14px" }}>
        <div style={{ width:"100%", maxWidth:420, background:step.bg, borderRadius:34, padding:"28px 20px 26px", boxShadow:"0 14px 48px rgba(0,0,0,.18)", display:"flex", flexDirection:"column", alignItems:"center" }}>
          <div style={{ display:"flex", alignItems:"center", gap:9, marginBottom:16, alignSelf:"flex-start" }}>
            {profile.photo
              ? <img src={profile.photo} alt="" style={{ width:42, height:42, borderRadius:"50%", objectFit:"cover", border:`2px solid ${C.blue3}` }}/>
              : <div style={{ width:42, height:42, borderRadius:"50%", background:C.blue3, display:"flex", alignItems:"center", justifyContent:"center", fontSize:20 }}>🧒</div>}
            <span style={{ fontFamily:FF, fontSize:14, color:C.navy, fontWeight:700 }}>يلا {profile.name}!</span>
          </div>
          <div style={{ fontSize:110, lineHeight:1, marginBottom:18 }}>{step.icon}</div>
          <h2 style={{ fontFamily:FF, fontSize:32, fontWeight:900, color:C.navy, margin:"0 0 24px", textAlign:"center", lineHeight:1.4 }}>{step.ar}</h2>
          <button onClick={tap} disabled={tapped}
            style={{ width:"100%", padding:"18px 0", borderRadius:18, border:"none", background:tapped?"#aabbc8":`linear-gradient(90deg,${C.blue2},${C.green2})`, color:C.white, fontFamily:FF, fontSize:22, fontWeight:700, cursor:tapped?"default":"pointer", transition:"all .2s" }}>
            {tapped ? "✅ شاطر!" : "✅ خلاص!"}
          </button>
          <button onClick={()=>speakArabic(step.ar)} style={{ marginTop:13, background:"transparent", border:`2px solid ${C.blue3}`, borderRadius:11, padding:"9px 22px", fontFamily:FF, fontSize:14, color:C.blue2, cursor:"pointer", fontWeight:700 }}>
            🔊 اسمع مرة ثانية
          </button>
        </div>
        <div style={{ display:"flex", gap:7, marginTop:18 }}>
          {steps.map((_,i) => (
            <div key={i} style={{ width:i===idx?28:9, height:9, borderRadius:9, background:i<idx?C.green2:i===idx?C.blue2:"rgba(255,255,255,.28)", transition:"all .3s" }}/>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── CALM ────────────────────────────────────────────────────────────────────
function CalmScreen({ onClose }) {
  return (
    <div style={{ position:"fixed", inset:0, zIndex:9999, backgroundColor:"#A8D8EA", display:"flex", alignItems:"center", justifyContent:"center" }}>
      <button onClick={onClose} style={{ position:"absolute", top:24, left:24, background:"rgba(255,255,255,.3)", border:"none", borderRadius:50, width:48, height:48, cursor:"pointer", fontSize:21, color:"#2E7DA6", fontWeight:700 }}>✕</button>
      <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:40 }}>
        <div style={{ display:"flex", gap:56 }}>
          <div style={{ width:46, height:62, borderRadius:"50%", backgroundColor:"#2E7DA6", animation:"blink 4s infinite" }}/>
          <div style={{ width:46, height:62, borderRadius:"50%", backgroundColor:"#2E7DA6", animation:"blink 4s infinite .2s" }}/>
        </div>
        <svg width="140" height="70" viewBox="0 0 140 70" style={{ overflow:"visible" }}>
          <path d="M15 10 Q70 70 125 10" stroke="#2E7DA6" strokeWidth="9" fill="none" strokeLinecap="round"/>
        </svg>
      </div>
      <style>{`@keyframes blink{0%,88%,100%{transform:scaleY(1)}93%{transform:scaleY(.07)}}`}</style>
    </div>
  );
}

// ─── NIGHT PREVIEW ────────────────────────────────────────────────────────────
function NightModal({ profile, onClose }) {
  return (
    <div style={{ position:"fixed", inset:0, zIndex:8000, background:"rgba(0,0,0,.55)", display:"flex", alignItems:"flex-end", justifyContent:"center", direction:"rtl" }}>
      <div style={{ background:C.white, borderRadius:"26px 26px 0 0", width:"100%", maxWidth:500, padding:"18px 16px 32px", maxHeight:"86vh", overflowY:"auto" }}>
        <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:4 }}>
          <button onClick={onClose} style={{ background:"#EEF6F3", border:"none", borderRadius:10, width:38, height:38, display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer" }}>
            <svg viewBox="0 0 24 24" fill="none" width="19" height="19"><path d="M9 5l7 7-7 7" stroke={C.navy} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
          <h3 style={{ fontFamily:FF, fontSize:18, color:C.navy, margin:0 }}>🌙 روتين المساء</h3>
        </div>
        <p style={{ fontFamily:FF, fontSize:12, color:C.muted, margin:"4px 0 12px", paddingRight:48 }}>هيظهر تلقائياً لـ {profile.name} عند موعد النوم</p>
        <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
          {NIGHT_STEPS.map((s,i) => (
            <div key={i} style={{ display:"flex", alignItems:"center", gap:12, background:s.bg, borderRadius:14, padding:"11px 13px" }}>
              <div style={{ width:30, height:30, borderRadius:"50%", background:"rgba(46,125,166,.13)", display:"flex", alignItems:"center", justifyContent:"center", fontFamily:FF, fontSize:13, fontWeight:700, color:C.blue2 }}>{i+1}</div>
              <span style={{ fontSize:26 }}>{s.icon}</span>
              <span style={{ fontFamily:FF, fontWeight:700, color:C.navy, fontSize:15 }}>{s.ar}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── BOARD ────────────────────────────────────────────────────────────────────
function Board({ profile, onCalm }) {
  const [words, setWords]       = useState([]);
  const [activeCat, setActiveCat] = useState(null);
  const [showNight, setShowNight] = useState(false);

  const add     = w => setWords(ws => [...ws, w]);
  const delLast = () => setWords(ws => ws.slice(0, -1));
  const clear   = () => setWords([]);
  const speak   = () => words.length && speakArabic(words.join(" "));

  const QUICK = [
    { ar:"أنا",      photo:profile.photo, emoji:"🧒", word:"أنا" },
    { ar:"عايز",     emoji:"💭",           word:"عايز" },
    { ar:"مش عايز",  emoji:"🚫",           word:"مش عايز" },
    { ar:"نوم",      emoji:"🌙",           word:"نوم" },
    { ar:"أكل",      emoji:"🍽",           word:"أكل" },
    { ar:"تعبان",    emoji:"🤒",           word:"تعبان" },
    { ar:"حمّام",    emoji:"🚽",           word:"حمّام" },
  ];

  const SmileBtn = ({ onClick }) => (
    <button onClick={onClick} style={{ background:"rgba(255,255,255,.2)", border:"none", borderRadius:9, width:38, height:38, display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer" }}>
      <svg viewBox="0 0 32 32" width="22" height="22" fill="none">
        <circle cx="16" cy="16" r="13" fill="rgba(255,255,255,0.3)"/>
        <ellipse cx="11" cy="13" rx="2" ry="2.5" fill="white"/>
        <ellipse cx="21" cy="13" rx="2" ry="2.5" fill="white"/>
        <path d="M10 20 Q16 26 22 20" stroke="white" strokeWidth="2.2" fill="none" strokeLinecap="round"/>
      </svg>
    </button>
  );

  return (
    <div style={{ minHeight:"100vh", background:C.bg, direction:"rtl", display:"flex", flexDirection:"column" }}>
      {showNight && <NightModal profile={profile} onClose={()=>setShowNight(false)}/>}

      {/* Header */}
      <div style={{ background:`linear-gradient(90deg,${C.blue2},${C.green2})`, padding:"11px 13px", display:"flex", alignItems:"center", gap:8 }}>
        <span style={{ fontFamily:FF, color:C.white, fontSize:16, fontWeight:700, flex:1, textAlign:"center" }}>
          مرحباً {profile.name} ⭐ | {profile.friend}
        </span>
        <button onClick={()=>setShowNight(true)} style={{ background:"rgba(255,255,255,.2)", border:"none", borderRadius:9, width:38, height:38, display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer", fontSize:18 }}>🌙</button>
        <SmileBtn onClick={onCalm}/>
      </div>

      {/* Sentence bar */}
      <div style={{ background:C.white, margin:"9px 11px", borderRadius:16, padding:"9px 11px", boxShadow:"0 3px 12px rgba(0,0,0,.08)" }}>
        <div style={{ minHeight:40, display:"flex", alignItems:"center", flexWrap:"wrap", gap:5, marginBottom:8 }}>
          {words.length === 0
            ? <span style={{ color:C.muted, fontFamily:FF, fontSize:15 }}>اضغط على الصور علشان تكوّن جملة</span>
            : words.map((w,i) => <span key={i} style={{ background:C.blue3, color:C.navy, borderRadius:9, padding:"4px 11px", fontFamily:FF, fontWeight:700, fontSize:15 }}>{w}</span>)}
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:7 }}>
          <button onClick={delLast} disabled={!words.length}
            style={{ padding:"10px 3px", borderRadius:11, border:"none", background:words.length?"#E8F4FF":"#eee", color:words.length?C.blue2:"#aaa", fontFamily:FF, fontSize:12, fontWeight:700, cursor:words.length?"pointer":"not-allowed", display:"flex", flexDirection:"column", alignItems:"center", gap:2 }}>
            <span style={{ fontSize:19 }}>⌫</span><span>مسح كلمة</span>
          </button>
          <button onClick={clear} disabled={!words.length}
            style={{ padding:"10px 3px", borderRadius:11, border:"none", background:words.length?"#FFE8E8":"#eee", color:words.length?"#C0392B":"#aaa", fontFamily:FF, fontSize:12, fontWeight:700, cursor:words.length?"pointer":"not-allowed", display:"flex", flexDirection:"column", alignItems:"center", gap:2 }}>
            <span style={{ fontSize:19 }}>🗑️</span><span>امسح كل</span>
          </button>
          <button onClick={speak} disabled={!words.length}
            style={{ padding:"10px 3px", borderRadius:11, border:"none", background:words.length?`linear-gradient(135deg,${C.blue2},${C.green2})`:"#eee", color:words.length?C.white:"#aaa", fontFamily:FF, fontSize:12, fontWeight:700, cursor:words.length?"pointer":"not-allowed", display:"flex", flexDirection:"column", alignItems:"center", gap:2 }}>
            <span style={{ fontSize:19 }}>🔊</span><span>اقرأ</span>
          </button>
        </div>
      </div>

      {/* Quick 7 icons */}
      <div style={{ padding:"0 11px", marginBottom:9 }}>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:8 }}>
          {QUICK.map((item,i) => (
            <button key={i} onClick={()=>{ add(item.word); speakArabic(item.word); }}
              style={{ background:C.white, border:`2px solid ${C.blue3}`, borderRadius:15, padding:"11px 6px", cursor:"pointer", display:"flex", flexDirection:"column", alignItems:"center", gap:5, boxShadow:"0 2px 7px rgba(0,0,0,.07)" }}>
              {item.photo
                ? <img src={item.photo} alt="" style={{ width:44, height:44, borderRadius:"50%", objectFit:"cover", border:`2px solid ${C.blue3}` }}/>
                : <span style={{ fontSize:28 }}>{item.emoji}</span>}
              <span style={{ fontFamily:FF, fontWeight:700, color:C.navy, fontSize:12 }}>{item.ar}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Categories */}
      <div style={{ padding:"0 11px 8px" }}>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(5,1fr)", gap:6 }}>
          {Object.entries(CATS).map(([key,cat]) => {
            const active = activeCat === key;
            return (
              <button key={key} onClick={()=>setActiveCat(active?null:key)}
                style={{ padding:"7px 2px", borderRadius:11, border:`2px solid ${active?cat.color:C.blue3}`, background:active?cat.color:C.white, color:active?C.white:C.navy, fontFamily:FF, fontSize:11, fontWeight:700, cursor:"pointer", display:"flex", flexDirection:"column", alignItems:"center", gap:2, transition:"all .15s" }}>
                <span style={{ fontSize:17 }}>{cat.emoji}</span>
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>
        {activeCat && (
          <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:6, marginTop:7 }}>
            {CATS[activeCat].items.map((item,i) => (
              <button key={i} onClick={()=>{ add(item.ar); speakArabic(item.ar); }}
                style={{ background:C.white, border:`2px solid ${CATS[activeCat].color}55`, borderRadius:12, padding:"8px 3px", cursor:"pointer", display:"flex", flexDirection:"column", alignItems:"center", gap:3 }}>
                <span style={{ fontSize:24 }}>{item.e}</span>
                <span style={{ fontFamily:FF, fontWeight:700, color:C.navy, fontSize:11 }}>{item.ar}</span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── ROOT ─────────────────────────────────────────────────────────────────────
export default function App() {
  const [profile,   setProfile]   = useState(null);
  const [phase,     setPhase]     = useState("board");
  const [rType,     setRType]     = useState(null);
  const [calm,      setCalm]      = useState(false);
  const [doneToday, setDoneToday] = useState({ morning:false, night:false });

  useEffect(() => {
    const link = document.createElement("link");
    link.href = "https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic:wght@400;700;900&display=swap";
    link.rel  = "stylesheet";
    document.head.appendChild(link);
    const s = document.createElement("style");
    s.textContent = `* { box-sizing: border-box; } body { margin: 0; background: #EEF6F3; }`;
    document.head.appendChild(s);
  }, []);

  function startApp(p) {
    setProfile(p);
    const needed = whichRoutine(p);
    if (needed) { setRType(needed); setPhase("routine"); }
    else setPhase("board");
  }

  function finishRoutine() {
    setDoneToday(d => ({ ...d, [rType]: true }));
    setPhase("board");
  }



  useEffect(() => {
    if (!profile) return;
    const id = setInterval(() => {
      const needed = whichRoutine(profile);
      if (needed && !doneToday[needed] && phase !== "routine") {
        setRType(needed); setPhase("routine");
      }
    }, 60000);
    return () => clearInterval(id);
  }, [profile, phase, doneToday]);

  if (!profile) return <Onboarding onDone={startApp}/>;

  return (
    <>
      {calm && <CalmScreen onClose={()=>setCalm(false)}/>}
      {phase === "routine" && <RoutineScreen profile={profile} type={rType} onComplete={finishRoutine} onCalm={()=>setCalm(true)}/>}
      {phase === "board"   && <Board profile={profile} onCalm={()=>setCalm(true)}/>}
    </>
  );
}
